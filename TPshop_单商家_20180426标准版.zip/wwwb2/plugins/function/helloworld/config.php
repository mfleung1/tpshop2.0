<?php
return array(
    'code'=> 'helloworld',
    'name' => 'HelloWorld插件',
    'version' => 'v1.2.0,v1.2.1,v1.2.2,v1.2.3', // 适合TPshop 哪些版本
    'author' => 'IT宇宙人',
    'desc' => '适合v1.2.0 , v1.2.1',
    'icon' => 'logo.jpg',    
);