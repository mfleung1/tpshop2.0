<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/8/25
 * Time: 14:26
 */

namespace app\common\model;
use think\Model;

class ReturnGoods extends Model {


}